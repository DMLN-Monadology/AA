import React from 'react';

const Recorder = () =>  (
  <div className='recorder'>
    Hello World
  </div>
);



 export default Recorder;
