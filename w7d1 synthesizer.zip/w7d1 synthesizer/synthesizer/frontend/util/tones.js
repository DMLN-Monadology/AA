export const TONES = {
  'a': 523.25,
  's': 587.33,
  'd': 659.25,
  'f': 698.46,
  'g': 783.99
};


export const NOTE_NAMES = [
  'a','s','d','f','g'
];
