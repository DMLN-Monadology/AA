# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)


cat1 = Cat.create(birth_date: Date.new(2014,10,18), color: 'black', name: 'Chairman Meow', sex: 'M')

cat2 = Cat.create(birth_date: Date.new(1958, 7, 10), color: 'orange', name: 'Meow Zedong', sex: 'M')
