class CatRentalRequest < ActiveRecord::Base

  validates :cat_id, :status, :start_date, :end_date, presence: true
  validates :status, inclusion: { in: %w(APPROVED DENIED PENDING),
    message: "%{value} is not a valid status"}

  validate :overlapping_requests, :overlapping_approved_requests

  def overlapping_requests
  end

  def overlapping_approved_requests
  end 

end
