class Cat < ActiveRecord::Base
  COLORS = ["brown", "black", "white", "grey", "orange"]
  validates :birth_date, :color, :name, :sex, presence: true
  validates :sex, length: { is: 1}
  validates :sex, inclusion: { in: %w(M F),
    message: "%{value} is not a valid sex"}
  validates :color, inclusion: { in: COLORS,
    message: "%{value} is not a valid color"}

  def age
    (Date.today - self.birth_date).to_i / 365
  end
end
