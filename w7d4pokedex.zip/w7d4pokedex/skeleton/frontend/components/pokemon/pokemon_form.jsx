import React from 'react';
import {createOnePokemon} from '../../actions/pokemon_actions';

class PokemonForm extends React.Component {

  constructor(props) {
    super(props);
    this.state = props.pokemon;
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);

  }

  handleSubmit(event) {
    event.preventDefault();
    this.props.createPokemon(this.state);
  }

  handleChange(property) {
    return e => {
      let fieldValue = e.target.value;

      if (property === "attack" || property === "defense") {
        fieldValue = parseInt(fieldValue);
      }
      this.setState({[property]: fieldValue});
    };
  }


  render() {
    return (
      <form>
        <input onChange={this.handleChange("name")} type="text" name="pokemon[name]" placeholder="Name"/><br/>
        <input onChange={this.handleChange("image_url")} type="text" name="pokemon[image_url]" placeholder="Image Url"/><br/>

        <select onChange={this.handleChange("poke_type")} name="pokemon[poke_type]">
          <option selected="selected" value="bug">bug</option>
          <option value="dragon">dragon</option>
          <option value="electric">electric</option>
          <option value="fighting">fighting</option>
          <option value="fire">fire</option>
          <option value="flying">flying</option>
          <option value="ghost">ghost</option>
          <option value="grass">grass</option>
          <option value="ground">ground</option>
          <option value="ice">ice</option>
          <option value="normal">normal</option>
          <option value="poison">poison</option>
          <option value="psychic">psychic</option>
          <option value="rock">rock</option>
          <option value="steel">steel</option>
          <option value="water">water</option>
        </select><br/>

      <input onChange={this.handleChange("attack")} type="text" name="pokemon[attack]" placeholder="attack"/><br/>
        <input onChange={this.handleChange("defense")} type="text" name="pokemon[defense]" placeholder="defense"/><br/>
        <input onChange={this.handleChange("move")} type="text" name="pokemon[move][]" placeholder="move 1"/><br/>
        <input onChange={this.handleChange("move")} type="text" name="pokemon[move][]" placeholder="move 2"/><br/>

        <button onClick={this.handleSubmit}>Create New Pokemon</button>

      </form>
    );
  }
}


export default PokemonForm;
