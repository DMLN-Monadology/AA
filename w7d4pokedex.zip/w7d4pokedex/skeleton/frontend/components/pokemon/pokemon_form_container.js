import {connect} from 'react-redux';
import {createOnePokemon} from '../../actions/pokemon_actions';
import PokemonForm from './pokemon_form';

const mapStateToProps = {pokemon: {}} => ({
    pokemon
});

const mapDispatchToProps = dispatch => ({
  createPokemon: (params) => dispatch(createOnePokemon(params))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PokemonForm);
