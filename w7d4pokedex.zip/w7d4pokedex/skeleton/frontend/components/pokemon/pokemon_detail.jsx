import React from 'react';
import {withRouter} from 'react-router';

const PokemonDetails = (props) => {
  // debugger
  // let index = null
  // const displayItemDetail = () => (index = item.id);

return (
  <div className = "pokemon-detail">
    <img src={props.pokemonDetail.image_url}/>
    <h2>{props.pokemonDetail.name}</h2>
    <p>Type: {props.pokemonDetail.poke_type}</p>
    <p>Attack: {props.pokemonDetail.attack}</p>
    <p>Defense: {props.pokemonDetail.defense}</p>
    <p>Moves: {props.pokemonDetail.moves}</p>
    <p>Items:</p>
    <ul>
      {
        props.pokemonDetail.items.map((item) => (
          <li key={item.id} onClick={ () => props.router.push(`pokemon/${props.pokemonDetail.id}/items/${item.id}`) }>{item.name}</li>)
        )
      }
    </ul>
    {props.children}
  </div>
);};

export default withRouter(PokemonDetails);
