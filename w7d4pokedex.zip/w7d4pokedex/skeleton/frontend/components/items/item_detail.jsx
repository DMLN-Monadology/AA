import React from 'react';

export const ItemDetail =  ({pokemonItem}) => {
  return (
  <div>
    <p>{pokemonItem.name}</p>
    <p>Happiness: {pokemonItem.happiness}</p>
    <p>Price: ${pokemonItem.price}</p>
  </div>
);};
