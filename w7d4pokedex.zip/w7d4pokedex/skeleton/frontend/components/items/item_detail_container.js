import React from 'react';
import {connect} from 'react-redux';
import {selectPokemonItem} from '../../reducers/selectors';
import {ItemDetail} from './item_detail';

const mapStateToProps = ({pokemonDetail}, ownProps) => {
  return ({
  pokemonItem: selectPokemonItem(pokemonDetail, ownProps.params.itemID)
});};

export default connect(
  mapStateToProps
)(ItemDetail);
