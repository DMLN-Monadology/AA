class Game {
  constructor() {
    this.towers = [[3, 2], [1], []];
  }

  printTowers() {
    console.log(this.towers);
  }

  promptMove(callback){
    this.printTowers();
    reader.question("From which tower would you like to move a piece?",
      function(answer) {
        let fromTower = answer;
        reader.question("To which tower would you like it moved?",
          function(answer) {
          let toTower = answer;
          callback(fromTower, toTower)
        }
      );
    }
    );
  }

  isValidMove(fromTower, toTower) {
    let dupFromTower = this.towers[fromTower].slice();
    let dupToTower = this.towers[toTower].slice();

    let movingDisc = dupFromTower.pop();
    let residentDisc = dupToTower.pop();

    this.printTowers();
    console.log(`fromTower: ${fromTower}, toTower: ${toTower}`);
    console.log(`moving disc: ${movingDisc}`);
    console.log(`residentDisc: ${residentDisc}`);
    console.log(`dupFromTower: ${dupFromTower}`);
    console.log(`dupToTower: ${dupToTower}`);

    if ( movingDisc < residentDisc || this.towers[toTower].length === 0) {
      return true;
    }
    return false;
  }
}

// const readline = require('readline');
//
// const reader = readline.createInterface( {
//   input: process.stdin,
//   output: process.stdout
// });

let game = new Game;
console.log(game.isValidMove(0, 2)); // true
console.log(game.isValidMove(1, 0)); // true

console.log(game.isValidMove(0, 1)); // false
console.log(game.isValidMove(0, 0)); // false
console.log(game.isValidMove(2, 1)); // false







//
