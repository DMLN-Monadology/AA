class InfiniteTweets {
  constructor() {
    this.maxCreatedAt = null;
    this.$more = $('.more-tweets');
    this.$more.click(event => {
      this.fetchTweets();
    });
  }

  fetchTweets() {
    $.ajax({
      url: '/feed',
      type: 'GET',
      dataType: 'json',
      data: {
        maxCreatedAt: this.maxCreatedAt
      },
      success: res => {
        this.insertTweets(res);
        let date = res[res.length - 1].created_at;
        this.maxCreatedAt = date;
      }
    });
  }

  insertTweets(res) {
    console.log(res);
    res.forEach(tweet => {
      let $li = $('<li>');
      $li.text(JSON.stringify(tweet));
      $('#feed').append($li);
    });
  }

}

module.exports = InfiniteTweets;
