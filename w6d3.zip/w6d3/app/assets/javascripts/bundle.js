/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	const FollowToggle = __webpack_require__(1);
	const UsersSearch = __webpack_require__(2);
	const TweetCompose = __webpack_require__(4);
	const InfiniteTweets = __webpack_require__(5);
	
	$( () => {
	  $('.follow-toggle').each(button => {
	    new FollowToggle(button);
	  });
	  new UsersSearch();
	  new TweetCompose();
	  new InfiniteTweets();
	});


/***/ },
/* 1 */
/***/ function(module, exports) {

	class FollowToggle {
	  constructor(el, options) {
	    this.$el = $(el);
	    this.userId = this.$el.data("user-id") || options.userId;
	    this.followState = (this.$el.data('initial-follow-state') ||
	                        options.followState);
	    this.render();
	    this.$el.click(e => {
	      e.preventDefault();
	      this.handleClick(e);
	    });
	  }
	
	  render() {
	    if (this.followState === 'followed') {
	      this.$el.text('Unfollow!');
	    } else {
	      this.$el.text('Follow');
	    }
	  }
	
	  handleClick(event) {
	    const method = this.followState === 'followed' ? 'DELETE' : 'POST';
	    this.$el.addClass('loading');
	    $.ajax({
	      url: `/users/${this.userId}/follow`,
	      type: method,
	      dataType: 'json',
	      success: res => {
	        this.toggleFollowState();
	        this.render();
	      }
	    }).always(() => {
	      this.$el.removeClass('loading');
	    });
	  }
	
	  toggleFollowState() {
	    if (this.followState === 'followed') {
	      this.followState = 'unfollowed';
	    } else {
	      this.followState = 'followed';
	    }
	  }
	}
	
	module.exports = FollowToggle;


/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	const FollowToggle = __webpack_require__(1);
	
	class UsersSearch {
	  constructor() {
	    this.$el = $('.users-search');
	    this.$input = $('.users-search > input');
	    this.$ul = $('.users-search > ul');
	    this.$el.on('keyup', e => {
	      this.inputVal = this.$input.val();
	      this.handleInput(e);
	    });
	  }
	
	  handleInput(event) {
	    console.log(event);
	    console.log(this.$input.val());
	    $.ajax({
	      url: './search',
	      type: 'GET',
	      dataType: 'json',
	      data: {
	        query: this.$input.val()
	      },
	      success: res => {
	        this.createList(res);
	      }
	    });
	  }
	
	  createList(users) {
	    this.$ul.empty();
	
	    users.forEach( user => {
	      let $li = $("<li>");
	      $li.text(user.username);
	      let $button = $('<button>');
	      let options = {
	        userId: user.id,
	        followedState: user.followed ? 'followed' : 'unfollowed'
	      };
	      new FollowToggle($button, options);
	      $li.append($button);
	      this.$ul.append($li);
	    });
	  }
	}
	
	module.exports = UsersSearch;


/***/ },
/* 3 */,
/* 4 */
/***/ function(module, exports) {

	class TweetCompose {
	  constructor() {
	    this.$el = $('.tweet-compose');
	    console.log(this.$el);
	    this.$el.on('click', 'input[type=Submit]', event => {
	    });
	    this.$el.on('keyup', 'textarea', () => {
	      this.updateCount();
	    });
	    $('.add-mentioned-user').click(this.addMentionedUser);
	    // $('.remove-mentioned-user').click(this.removeMentionedUser);
	    this.$el.on('click', '.remove-mentioned-user', event => {
	      this.removeMentionedUser(event);
	    });
	  }
	
	  submit() {
	    const content = $(".tweet-compose textarea").val();
	    const mentionedUserIds = $(".tweet-compose select").val();
	    $.ajax({
	      url: "/tweets",
	      type: "POST",
	      dataType: "json",
	      data: {
	        tweet: {
	          content: content,
	          mentioned_user_ids: [mentionedUserIds]
	        }
	      },
	      success: res => {
	        this.handleSuccess(res);
	      }
	    });
	  }
	
	  clearInput() {
	    this.$el.find('textarea, select').val('');
	  }
	
	  handleSuccess(res) {
	    this.clearInput();
	    let $li = $('<li>');
	    $li.text(`${res.content} -- ${res.user.username} -- ${res.created_at}`);
	    $('#feed').prepend($li);
	  }
	
	  updateCount() {
	    const value = $(this.$el.find('textarea')).val();
	    let remaining = 140 - value.length;
	    $('.chars-left').text(remaining);
	  }
	
	  addMentionedUser() {
	    const $scriptTag = $('script[type="text/template"]');
	    const select = $scriptTag.html();
	    $('.mentioned-users').prepend(select);
	  }
	
	  removeMentionedUser(event) {
	    console.log(event);
	    console.log(event.currentTarget);
	    console.log(event.target);
	    const deleteTarget = $(event.currentTarget).parent();
	    deleteTarget.remove();
	  }
	}
	
	module.exports = TweetCompose;


/***/ },
/* 5 */
/***/ function(module, exports) {

	class InfiniteTweets {
	  constructor() {
	    this.maxCreatedAt = null;
	    this.$more = $('.more-tweets');
	    this.$more.click(event => {
	      this.fetchTweets();
	    });
	  }
	
	  fetchTweets() {
	    $.ajax({
	      url: '/feed',
	      type: 'GET',
	      dataType: 'json',
	      data: {
	        maxCreatedAt: this.maxCreatedAt
	      },
	      success: res => {
	        this.insertTweets(res);
	        let date = res[res.length - 1].created_at;
	        this.maxCreatedAt = date;
	      }
	    });
	  }
	
	  insertTweets(res) {
	    console.log(res);
	    res.forEach(tweet => {
	      let $li = $('<li>');
	      $li.text(JSON.stringify(tweet));
	      $('#feed').append($li);
	    });
	  }
	
	}
	
	module.exports = InfiniteTweets;


/***/ }
/******/ ]);
//# sourceMappingURL=bundle.js.map