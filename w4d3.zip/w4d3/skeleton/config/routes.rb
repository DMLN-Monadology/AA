NinetyNineCatsDay1::Application.routes.draw do
  # get 'users/Sessions'

  resources :users, only: [:new, :create]
  resource :session, only: [:new, :create, :destroy]

  resources :cats, except: :destroy
  resources :cat_rental_requests, only: [:create, :new] do
    post "approve", on: :member
    post "deny", on: :member
  end

  root to: redirect("/cats")
end
