require 'test_helper'

class CatsHelperTest < ActionView::TestCase
end
