const Router = function(node, routes) {
  this.node = node;
  this.routes = routes;
};

Router.prototype.start = function () {
  this.render();
  let that = this;

  window.addEventListener('hashchange', function () {
    that.render();
  });
};

Router.prototype.render = function () {
  this.node.innerHTML = "";
  let route = this.activeRoute();
  let newNode = document.createElement("p");
  newNode.innerHTML = route;
  this.node.appendChild(newNode);
};

Router.prototype.activeRoute = function () {
  let routeName = window.location.hash.slice(1);
  return this.routes[routeName];
};

module.exports = Router;
