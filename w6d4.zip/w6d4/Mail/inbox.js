let Inbox;

Inbox.prototype.render = function() {
  let newUl = document.createElement("ul");
  newUl.className = "messages";
  newUl.innerHTML = "An Inbox Message";

  return newUl;
};

module.exports = Inbox;
