/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	const Router = __webpack_require__(2);
	const Inbox = __webpack_require__(3);

	document.addEventListener("DOMContentLoaded", () => {
	  document.querySelectorAll(".sidebar-nav li").forEach (li => {
	    li.addEventListener("click", event => {
	      window.location.hash = event.target.innerText.toLowerCase();
	    });
	  });
	  let contentNode = document.querySelector(".content");

	  let newRouter = new Router(contentNode);
	  newRouter.start();


	});

	let routes = {
	  inbox: Inbox
	};


/***/ },
/* 1 */,
/* 2 */
/***/ function(module, exports) {

	const Router = function(node, routes) {
	  this.node = node;
	  this.routes = routes;
	};

	Router.prototype.start = function () {
	  this.render();
	  let that = this;

	  window.addEventListener('hashchange', function () {
	    that.render();
	  });
	};

	Router.prototype.render = function () {
	  this.node.innerHTML = "";
	  let route = this.activeRoute();
	  let newNode = document.createElement("p");
	  newNode.innerHTML = route;
	  this.node.appendChild(newNode);
	};

	Router.prototype.activeRoute = function () {
	  let routeName = window.location.hash.slice(1);
	  return this.routes[routeName];
	};

	module.exports = Router;


/***/ },
/* 3 */
/***/ function(module, exports) {

	let Inbox;

	Inbox.prototype.render = function() {
	  let newUl = document.createElement("ul");
	  newUl.className = "messages";
	  newUl.innerHTML = "An Inbox Message";

	  return newUl;
	};

	module.exports = Inbox;


/***/ }
/******/ ]);