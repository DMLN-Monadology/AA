const Router = require('./router.js');
const Inbox = require('./inbox.js');

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".sidebar-nav li").forEach (li => {
    li.addEventListener("click", event => {
      window.location.hash = event.target.innerText.toLowerCase();
    });
  });
  let contentNode = document.querySelector(".content");

  let newRouter = new Router(contentNode);
  newRouter.start();


});

let routes = {
  inbox: Inbox
};
