require 'rails_helper'

RSpec.describe Api::PokemonController, type: :controller do

end
